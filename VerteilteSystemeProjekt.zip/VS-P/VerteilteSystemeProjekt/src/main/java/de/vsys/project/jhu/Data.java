package de.vsys.project.jhu;


public class Data {
    /*
    @author: Mike Witkowski
    This class is the template for the json data from the john hopkins university
     */
    private CountryData[] Germany;

    public CountryData[] getData() {
        return Germany;
    }
}