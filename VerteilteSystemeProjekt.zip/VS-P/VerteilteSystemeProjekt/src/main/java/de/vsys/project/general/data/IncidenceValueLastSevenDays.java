package de.vsys.project.general.data;


public class IncidenceValueLastSevenDays {
    /*
    @author: David Rohrschneider
    This class is the template for the data which we return to the user
     */
    private double incidenceValueLastSevenDays;

    public double getIncidenceValueLastSevenDays() {
        return incidenceValueLastSevenDays;
    }

    public void setIncidenceValueLastSevenDays(double incidenceValueLastSevenDays) {
        this.incidenceValueLastSevenDays = incidenceValueLastSevenDays;
    }
}