package de.vsys.project.general.data;


public class AverageIncreaseLastNDays {
    /*
    @author: David Rohrschneider
    This class is the template for the data which we return to the user
     */
    private double averageIncreaseLastNDays;

    public double getAverageIncreaseLastNDays() {
        return averageIncreaseLastNDays;
    }

    public void setAverageIncreaseLastNDays(double averageIncreaseLastNDays) {
        this.averageIncreaseLastNDays = averageIncreaseLastNDays;
    }
}