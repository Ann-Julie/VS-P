package de.vsys.project.general.data;


public class NewInfectionsLastTwentyFourHours {
    /*
    @author: David Rohrschneider
    This class is the template for the data which we return to the user
     */
    private int newInfectionsLastTwentyFourHours;

    public int getNewInfectionsLastTwentyFourHours() {
        return newInfectionsLastTwentyFourHours;
    }

    public void setNewInfectionsLastTwentyFourHours(int newInfectionsLastTwentyFourHours) {
        this.newInfectionsLastTwentyFourHours = newInfectionsLastTwentyFourHours;
    }
}