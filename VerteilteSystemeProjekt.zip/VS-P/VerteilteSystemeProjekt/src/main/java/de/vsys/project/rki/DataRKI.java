package de.vsys.project.rki;


public class DataRKI {
    /*
    @author: Maximilian Meyer
    This class is the template for the json data from the Robert Koch Institut
    */
    private Attributes[] features;

    public Attributes[] getData(){
        return features;
    }
}