package de.vsys.project.general.data;


public class TotalInfections {
    /*
    @author: Mike Witkowski
    This class is the template for the data which we return to the user
    */
    private int totalInfections;

    public int getTotalInfections() {
        return totalInfections;
    }

    public void setTotalInfections(int totalInfections) {
        this.totalInfections = totalInfections;
    }
}