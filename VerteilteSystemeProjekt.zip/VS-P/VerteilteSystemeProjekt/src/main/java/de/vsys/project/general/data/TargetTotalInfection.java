package de.vsys.project.general.data;


public class TargetTotalInfection {
    /*
    @author: David Rohrschneider
    This class is the template for the data which we return to the user
     */
    private double targetTotalInfection;

    public double getTargetTotalInfection() {
        return targetTotalInfection;
    }

    public void setTargetTotalInfection(double targetTotalInfection) {
        this.targetTotalInfection = targetTotalInfection;
    }
}