package de.vsys.project.general.data;


public class IncreaseLastTwentyFourHours {
    /*
    @author: David Rohrschneider
    This class is the template for the data which we return to the user
     */
    private int increaseLastTwentyFourHours;

    public int getIncreaseLastTwentyFourHours() {
        return increaseLastTwentyFourHours;
    }

    public void setIncreaseLastTwentyFourHours(int increaseLastTwentyFourHours) {
        this.increaseLastTwentyFourHours = increaseLastTwentyFourHours;
    }
}