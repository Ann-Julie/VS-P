package de.vsys.project.rki;


public class Attributes {
    /*
    @author: Maximilian Meyer
    This class is the template for the json data from the Robert Koch Institution
    */
    private StateData attributes;

    public StateData getAttributes() {
        return attributes;
    }
}