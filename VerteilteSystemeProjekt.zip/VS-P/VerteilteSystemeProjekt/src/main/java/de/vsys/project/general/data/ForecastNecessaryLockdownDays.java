package de.vsys.project.general.data;


public class ForecastNecessaryLockdownDays {
    /*
    @author: David Rohrschneider
    This class is the template for the data which we return to the user
     */
    private double forecastNecessaryLockdownDays;

    public double getForecastNecessaryLockdownDays() {
        return forecastNecessaryLockdownDays;
    }

    public void setForecastNecessaryLockdownDays(double forecastNecessaryLockdownDays) {
        this.forecastNecessaryLockdownDays = forecastNecessaryLockdownDays;
    }
}