""""
@author: Ann-Julie Sinnaeve
all larger text messages from telegram VSys-CoV bot
"""

startCommandText = (
    """ 
    Herzlich Willkommen. Ich bin der VSys-CoV Bot! 
    Alle meine Funktionen finden Sie mit /help. 
    """)

helpCommandText = (
    """ 
    Auswahl: 
    Alle Informationen:
    /alldata 
    Aktuelle Gesamtinfektion in Deutschland:
    /totalinfec
    Zahl Neuinfektionen letzte 24 Stunden:
    /newinfeclast24h
    Ziel Gesamtinfektion für Zielinzidenzwert (35):
    /targettotalinfec
    Vorhersage Tage in Lockdown:
    /forecastlockdays
    Inzidenzwert der  letzten 7 Tage:
    /incvallast7days 
    Durchschnittlicher Anstieg 
    der letzten n Tage:
    /avgincrlastndays
    Anstieg der letzten 24 Stunden:
    /incrlast24h
    """)